import React from 'react';
import ReactDOM from 'react-dom';
import imgs from './honda.jpg';
import stl from './style.css';
import img from './china.jpg';
import {BrowserRouter as Router, Link, Route} from 'react-router-dom';

class Slider extends React.Component{
    render(){
        return(
            <Router> 
                <div>
                    <h1>This is Route</h1>
                    <Link to="/slid">Slide</Link>
                    <Link to="/">Home</Link>
                    <Route path="/slid" component={SlidCom} /> 
                     <Link to="/next">next</Link>
                    <Route path="/Next" component={Next} /> 
                    {/*<Route exact path="/" component={Slider} /> */}
                </div>

            </Router>
        )
        
    }
}
 
class SlidCom extends React.Component {

   
    render() {
        return (
            <div>
              <h1>This is Slide</h1>
              <img src={imgs} />
              
             </div>
        )
    }
}
 
class Next extends React.Component {

   
    render() {
        return (
            <div>
              <h1>This is Slide</h1>
             
              <img src={img} />   
             </div>
        )
    }
}




class App extends React.Component{
    render(){
        return(

            <div>
            <h1>Hello React</h1>
            
            </div>
        );
    }
}
class Footer extends React.Component{
    render(){
        return(
            <div>
                <p>this is footer</p>
             <Footerchild name="this is footer name" id="1" />
            </div>
        )
    }

}

class  Footerchild extends React.Component{     
    render(){
        return(
            <div>
                <p>this is footer helper</p>
                  <p>{this.props.name}</p>
              
                <img src={img} />
                
                </div>
        )
    }
} 

ReactDOM.render(<Slider/>,document.getElementById('slide'));
ReactDOM.render(<App />, document.getElementById('mydiv'));
ReactDOM.render(<Footer />, document.getElementById('foot'));